﻿exports.handler = async (event) => {
  console.log('Runway EventBridge processor invoked', JSON.stringify(event))
  return { statusCode: 200, body: 'ok' }
}
