exports.handler = async (event) => {
  for (const record of event.Records || []) {
    console.log('Processing message:', record.body);
  }
  return { batchItemFailures: [] };
};